<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Administration — Hôtel des Rêves Lucides</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="admin.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-dark text-light">

<div id="loginView" class="container py-5 d-none">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card bg-secondary-subtle text-dark shadow">
                <div class="card-header bg-dark text-warning">
                    <h3 class="mb-0">
                        <i class="bi bi-shield-lock me-2"></i>Connexion administrateur
                    </h3>
                </div>
                <div class="card-body">
                    <div id="loginAlert" class="alert d-none"></div>

                    <form id="loginForm">
                        <div class="mb-3">
                            <label for="username" class="form-label">Identifiant</label>
                            <input type="text" id="username" name="username" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Mot de passe</label>
                            <input type="password" id="password" name="password" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-dark w-100">
                            <i class="bi bi-box-arrow-in-right me-1"></i>Se connecter
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="adminView" class="d-none">
    <!-- HEADER -->
    <div class="container-fluid bg-black py-3 mb-4 border-bottom border-secondary">
        <div class="container d-flex justify-content-between align-items-center">
            <div>
                <h1 class="mb-0">🌙 Hôtel des Rêves Lucides</h1>
                <small class="text-secondary">Panneau d'administration</small>
            </div>

            <div class="d-flex align-items-center gap-2">
                <span class="badge bg-warning text-dark fs-6" id="adminBadge">Administrateur</span>
                <button class="btn btn-outline-light btn-sm" id="btnLogout">
                    <i class="bi bi-box-arrow-right me-1"></i>Déconnexion
                </button>
            </div>
        </div>
    </div>

   
    <div class="container pb-5">

        <!-- ══════════════════════════════════════════
            1. DEMANDES DE RÉSERVATION
        ══════════════════════════════════════════ -->
        <div class="card bg-secondary-subtle text-dark mb-5">
            <div class="card-header bg-dark text-warning">
                <h4 class="mb-0"><i class="bi bi-calendar-check me-2"></i>Demandes de réservation</h4>
            </div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Arrivée</th>
                            <th>Départ</th>
                            <th>Personnes</th>
                            <th>Activités</th>
                            <th>Chambre</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="reservationsBody"></tbody>
                </table>
            </div>
        </div>

        <!-- ══════════════════════════════════════════
            2. GESTION DES CHAMBRES
        ══════════════════════════════════════════ -->
        <div class="card bg-secondary-subtle text-dark mb-5">
        <div class="card-header bg-dark text-warning d-flex justify-content-between align-items-center">
            <h4 class="mb-0"><i class="bi bi-door-open me-2"></i>Gestion des chambres</h4>
            <input type="date" class="form-control w-auto" id="dateChambres">
        </div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <div class="card text-dark h-100">
                        <img src="https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=400" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Nuit Étoilée</h5>
                            <p class="mb-1"><span id="libres-nuit-etoilee" class="badge bg-success">Libres: 15</span></p>
                            <p class="mb-0"><span id="reservees-nuit-etoilee" class="badge bg-danger">Réservées: 0</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card text-dark h-100">
                        <img src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Sensorielle</h5>
                            <p class="mb-1"><span id="libres-sensorielle" class="badge bg-success">Libres: 15</span></p>
                            <p class="mb-0"><span id="reservees-sensorielle" class="badge bg-danger">Réservées: 0</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card text-dark h-100">
                        <img src="https://images.unsplash.com/photo-1554995207-c18c203602cb?w=400" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Silence Absolu</h5>
                            <p class="mb-1"><span id="libres-silence-absolu" class="badge bg-success">Libres: 30</span></p>
                            <p class="mb-0"><span id="reservees-silence-absolu" class="badge bg-danger">Réservées: 0</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card text-dark h-100">
                        <img src="https://images.unsplash.com/photo-1590490360182-c33d57733427?w=400" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title">Suite Lucide</h5>
                            <p class="mb-1"><span id="libres-suite-lucide" class="badge bg-success">Libres: 20</span></p>
                            <p class="mb-0"><span id="reservees-suite-lucide" class="badge bg-danger">Réservées: 0</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!-- ══════════════════════════════════════════
            3. FACTURATION PAR CLIENT
        ══════════════════════════════════════════ -->
        <div class="card bg-secondary-subtle text-dark mb-5">
            <div class="card-header bg-dark text-warning">
                <h4 class="mb-0"><i class="bi bi-receipt me-2"></i>Facturation</h4>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label fw-bold">Client</label>
                    <select class="form-select" id="clientFacture"></select>
                </div>
                <div id="factureDetail" class="d-none">
                    <table class="table table-bordered table-sm">
                        <thead class="table-dark">
                            <tr>
                                <th>Désignation</th>
                                <th class="text-end">Montant</th>
                            </tr>
                        </thead>
                        <tbody id="factureBody"></tbody>
                        <tfoot>
                            <tr id="ligneArrhes" class="table-danger d-none">
                                <td><i class="bi bi-dash-circle me-1"></i>Arrhes reçues</td>
                                <td class="text-end text-danger fw-bold" id="montantArrhes">— 0 €</td>
                            </tr>
                            <tr id="ligneReduction" class="table-warning d-none">
                                <td><i class="bi bi-tag me-1"></i>Réduction appliquée</td>
                                <td class="text-end text-warning fw-bold" id="montantReduction">— 0 €</td>
                            </tr>
                            <tr class="table-dark fw-bold">
                                <td>TOTAL</td>
                                <td class="text-end" id="factureTotal">0 €</td>
                            </tr>
                        </tfoot>
                    </table>

                    <div class="row g-3 mt-1">
                        <div class="col-md-4">
                            <div class="card text-dark">
                                <div class="card-header bg-secondary text-white">
                                    <i class="bi bi-cash-coin me-1"></i>Arrhes
                                </div>
                                <div class="card-body">
                                    <p class="mb-2" id="arrheStatut">
                                        <span class="badge bg-danger">Non reçues</span>
                                    </p>
                                    <div class="input-group mb-2">
                                        <span class="input-group-text">€</span>
                                        <input type="number" class="form-control" id="montantArrheInput" placeholder="Montant reçu">
                                    </div>
                                    <button class="btn btn-success w-100" id="btnConfirmerArrhes">
                                        <i class="bi bi-check-circle me-1"></i>Confirmer réception arrhes
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-dark">
                                <div class="card-header bg-secondary text-white">
                                    <i class="bi bi-percent me-1"></i>Réduction sur prestations
                                </div>
                                <div class="card-body">
                                    <select class="form-select mb-2" id="selectReduction">
                                        <option value="0">Aucune réduction</option>
                                        <option value="10">-10%</option>
                                        <option value="20">-20%</option>
                                        <option value="50">-50%</option>
                                    </select>
                                    <button class="btn btn-warning w-100" id="btnAppliquerReduction">
                                        <i class="bi bi-tag me-1"></i>Appliquer
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ══════════════════════════════════════════
            4. ACTIVITÉS — DEMANDES DU JOUR
        ══════════════════════════════════════════ -->
        <div class="card bg-secondary-subtle text-dark mb-5">
            <div class="card-header bg-dark text-warning d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><i class="bi bi-activity me-2"></i>Activités — Demandes du jour</h4>
                <input type="date" class="form-control w-auto" id="dateActivites" value="2026-05-01">
            </div>
            <div class="card-body">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Sélection</th>
                            <th>Client</th>
                            <th>Activité</th>
                            <th>Période</th>
                            <th>Participants</th>
                            <th>Message</th>
                            <th>Statut</th>
                        </tr>
                    </thead>
                    <tbody id="activitesBody"></tbody>
                </table>

                <div class="card text-dark mt-3">
                    <div class="card-header bg-secondary text-white">
                        <i class="bi bi-person-check me-1"></i>Valider les demandes sélectionnées
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Animateur</label>
                                <select class="form-select" id="selectAnimateur">
                                    <option>— Choisir un animateur —</option>
                                    <option>Jean-Pierre (Tennis)</option>
                                    <option>Sophie (Bateau)</option>
                                    <option>Amira (Méditation)</option>
                                    <option>Luc (Randonnée)</option>
                                </select>
                            </div>
                            <div class="col-md-8 d-flex align-items-end gap-2">
                                <button class="btn btn-success w-100" id="btnValiderActivites">
                                    <i class="bi bi-check2-all me-1"></i>Valider la sélection
                                </button>
                                <button class="btn btn-danger w-100" id="btnRefuserActivites">
                                    <i class="bi bi-x-circle me-1"></i>Refuser la sélection
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <footer class="bg-black text-center text-secondary py-3 border-top border-secondary">
        <small>© 2026 Hôtel des Rêves Lucides — Administration</small>
    </footer>

    <!-- MODAL — Mail de confirmation généré -->
    <div class="modal fade" id="modalMail" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content bg-dark text-light border-secondary">
                <div class="modal-header border-secondary">
                    <h5 class="modal-title">
                        <i class="bi bi-envelope-check me-2 text-success"></i>
                        Réservation validée — Mail à envoyer au client
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-success">
                        <i class="bi bi-person-plus me-2"></i>
                        Compte client créé avec succès. Copiez le message ci-dessous dans votre logiciel de mail.
                    </div>
                    <div class="row mb-3 g-2">
                        <div class="col-md-4">
                            <div class="card text-dark text-center">
                                <div class="card-body py-2">
                                    <small class="text-muted d-block">URL de connexion</small>
                                    <strong id="infoUrl">—</strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-dark text-center">
                                <div class="card-body py-2">
                                    <small class="text-muted d-block">Identifiant (email)</small>
                                    <strong id="infoEmail">—</strong>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card text-dark text-center">
                                <div class="card-body py-2">
                                    <small class="text-muted d-block">Mot de passe généré</small>
                                    <strong class="text-warning" id="infoPassword">—</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card bg-light text-dark">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span><i class="bi bi-envelope me-1"></i>Message prêt à copier-coller</span>
                            <button class="btn btn-sm btn-outline-dark" id="btnCopierMail">
                                <i class="bi bi-clipboard me-1"></i>Copier
                            </button>
                        </div>
                        <div class="card-body">
                            <pre id="mailContent" class="mb-0" style="white-space: pre-wrap; font-size: .9rem;"></pre>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                    <button type="button" class="btn btn-success" id="btnCopierMailFooter">
                        <i class="bi bi-clipboard-check me-1"></i>Copier le mail
                    </button>
                </div>
            </div>
        </div>
    </div>


    <!-- fin adminView -->
</div>

<script src="admin.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>