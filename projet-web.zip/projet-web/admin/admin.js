$(document).ready(function () {
    verifierSession();

    $("#loginForm").on("submit", function (e) {


        $.ajax({
            url: "../api/admin_login.php",
            type: "POST",
            dataType: "json",
            data: {
                username: $("#username").val(),
                password: $("#password").val()
            },
            success: function (response) {
                if (response.success) {
                    afficherAdmin(response.username);
                    chargerDonneesAdmin();
                } else {
                    afficherErreurLogin(response.message);
                }
            },
            error: function () {
                afficherErreurLogin("Erreur serveur lors de la connexion.");
            }
        });
    });

    $("#btnLogout").on("click", function () {
        $.ajax({
            url: "../api/admin_logout.php",
            type: "POST",
            dataType: "json",
            success: function () {
                afficherLogin();
                $("#loginForm")[0].reset();
            },
            error: function () {
                alert("Erreur lors de la déconnexion.");
            }
        });
    });

    $(document).on("click", ".btn-accepter", function () {
        const id = $(this).data("id");
        traiterReservation(id, "accepter");
    });

    $(document).on("click", ".btn-refuser", function () {
        const id = $(this).data("id");
        traiterReservation(id, "refuser");
    });

    $("#btnCopierMail, #btnCopierMailFooter").on("click", function () {
        copierTexteMail();
    });

    const aujourdhui = new Date().toISOString().split("T")[0];
    $("#dateChambres").val(aujourdhui);

    $("#dateChambres").on("change", function () {
        chargerChambres();
    });

    $("#clientFacture").on("change", function () {
        const reservationId = $(this).val();

        if (reservationId) {
            chargerDetailFacture(reservationId);
        } else {
            $("#factureDetail").addClass("d-none");
        }
    });

    $("#btnAppliquerReduction").on("click", function () {
        const reservationId = $("#clientFacture").val();
        const reduction = $("#selectReduction").val();

        if (!reservationId) {
            alert("Veuillez choisir une réservation.");
            return;
        }

        appliquerReduction(reservationId, reduction);
    });

    $("#btnConfirmerArrhes").on("click", function () {
        const reservationId = $("#clientFacture").val();
        const montantArrhes = $("#montantArrheInput").val();

        if (!reservationId) {
            alert("Veuillez choisir une réservation.");
            return;
        }

        if (montantArrhes === "" || Number(montantArrhes) < 0) {
            alert("Veuillez saisir un montant d'arrhes valide.");
            return;
        }

        confirmerArrhes(reservationId, montantArrhes);
    });

    const dateJour = new Date().toISOString().split("T")[0];
    $("#dateActivites").val(dateJour);

    $("#dateActivites").on("change", function () {
        chargerActivites();
    });

    $("#btnValiderActivites").on("click", function () {
        traiterActivitesSelectionnees("valider");
    });

    $("#btnRefuserActivites").on("click", function () {
        traiterActivitesSelectionnees("refuser");
    });

});

function verifierSession() {
    $.ajax({
        url: "../api/admin_checkSession.php",
        type: "GET",
        dataType: "json",
        success: function (response) {
            if (response.loggedIn) {
                afficherAdmin(response.username);
                chargerDonneesAdmin();
            } else {
                afficherLogin();
            }
        },
        error: function () {
            afficherLogin();
        }
    });
}

function afficherLogin() {
    $("#adminView").addClass("d-none");
    $("#loginView").removeClass("d-none");
}

function afficherAdmin(username) {
    $("#loginView").addClass("d-none");
    $("#adminView").removeClass("d-none");
    $("#adminBadge").text("Administrateur : " + username);
    $("#loginAlert").addClass("d-none").removeClass("alert-danger alert-success").text("");
}

function afficherErreurLogin(message) {
    $("#loginAlert")
        .removeClass("d-none alert-success")
        .addClass("alert alert-danger")
        .text(message);
}

function chargerDonneesAdmin() {
    chargerReservations();
    chargerChambres();
    chargerFacturation();
    chargerActivites();
}

function chargerReservations() {
    $.ajax({
        url: "../api/admin_reservations.php",
        type: "GET",
        dataType: "json",
        success: function (response) {
            if (!response.success) {
                $("#reservationsBody").html(`
                    <tr>
                        <td colspan="9" class="text-center text-danger">
                            ${response.message}
                        </td>
                    </tr>
                `);
                return;
            }

            const reservations = response.reservations;
            let html = "";

            if (reservations.length === 0) {
                html = `
                    <tr>
                        <td colspan="9" class="text-center text-muted">
                            Aucune réservation en attente.
                        </td>
                    </tr>
                `;
            } else {
                reservations.forEach(function (reservation) {
                    let activites = "Aucune";

                    if (Array.isArray(reservation.activites) && reservation.activites.length > 0) {
                        activites = reservation.activites
                            .map(act => act.nom)
                            .join(", ");
                    }

                    html += `
                        <tr id="reservation-${reservation.id}">
                            <td>${reservation.id}</td>
                            <td>${reservation.nom}</td>
                            <td>${reservation.email}</td>
                            <td>${reservation.date_debut}</td>
                            <td>${reservation.date_fin}</td>
                            <td>${reservation.nb_personnes}</td>
                            <td>${activites}</td>
                            <td>${reservation.chambre}</td>
                            <td>
                                <button class="btn btn-success btn-sm btn-accepter" data-id="${reservation.id}">
                                    <i class="bi bi-check-circle"></i> Accepter
                                </button>
                                <button class="btn btn-danger btn-sm btn-refuser" data-id="${reservation.id}">
                                    <i class="bi bi-x-circle"></i> Refuser
                                </button>
                            </td>
                        </tr>
                    `;
                });
            }

            $("#reservationsBody").html(html);
        },
        error: function () {
            $("#reservationsBody").html(`
                <tr>
                    <td colspan="9" class="text-center text-danger">
                        Erreur lors du chargement des réservations.
                    </td>
                </tr>
            `);
        }
    });
}

function traiterReservation(id, action) {
    $.ajax({
        url: "../api/admin_traiterReservation.php",
        type: "POST",
        dataType: "json",
        data: {
            id: id,
            action: action
        },
        success: function (response) {
            if (response.success) {
                $("#reservation-" + id).fadeOut(300, function () {
                    $(this).remove();

                    if ($("#reservationsBody tr[id^='reservation-']").length === 0) {
                        $("#reservationsBody").html(`
                            <tr>
                                <td colspan="9" class="text-center text-muted">
                                    Aucune réservation en attente.
                                </td>
                            </tr>
                        `);
                    }
                });

                chargerChambres();

                if (action === "accepter" && response.mailData) {
                    afficherPopupMail(response.mailData);
                }
            } else {
                alert(response.message);
            }
        },
        error: function () {
            alert("Erreur serveur lors du traitement de la réservation.");
        }
    });
}

function afficherPopupMail(mailData) {
    $("#infoUrl").text(mailData.url);
    $("#infoEmail").text(mailData.email);
    $("#infoPassword").text(mailData.password);
    $("#mailContent").text(mailData.content);

    const modalElement = document.getElementById("modalMail");
    const modal = new bootstrap.Modal(modalElement);
    modal.show();
}

function copierTexteMail() {
    const texte = $("#mailContent").text();

    navigator.clipboard.writeText(texte)
        .then(function () {
            alert("Mail copié dans le presse-papiers.");
        })
        .catch(function () {
            alert("Impossible de copier automatiquement le mail.");
        });
}

function chargerChambres() {
    const dateSelectionnee = $("#dateChambres").val();

    if (!dateSelectionnee) {
        return;
    }

    $.ajax({
        url: "../api/admin_chambres.php",
        type: "GET",
        dataType: "json",
        data: {
            date: dateSelectionnee
        },
        success: function (response) {
            if (!response.success) {
                alert(response.message);
                return;
            }

            const chambres = response.chambres || {};

            mettreAJourCarteChambre("nuit-etoilee", chambres["Nuit Étoilée"]);
            mettreAJourCarteChambre("sensorielle", chambres["Sensorielle"]);
            mettreAJourCarteChambre("silence-absolu", chambres["Silence Absolu"]);
            mettreAJourCarteChambre("suite-lucide", chambres["Suite Lucide"]);
        },
        error: function () {
            alert("Erreur lors du chargement des chambres.");
        }
    });
}

function mettreAJourCarteChambre(cleHtml, infos) {
    if (!infos) {
        return;
    }

    $("#libres-" + cleHtml).text("Libres: " + infos.libres);
    $("#reservees-" + cleHtml).text("Réservées: " + infos.reservees);
}

function chargerFacturation() {
    $.ajax({
        url: "../api/admin_facturation_clients.php",
        type: "GET",
        dataType: "json",
        success: function (response) {
            if (!response.success) {
                $("#clientFacture").html('<option value="">Erreur de chargement</option>');
                return;
            }

            const clients = response.clients || [];
            let html = '<option value="">— Choisir une réservation —</option>';

            clients.forEach(function (client) {
                html += `
                    <option value="${client.id}">
                        ${client.nom} — #${client.id} — ${client.date_debut} → ${client.date_fin}
                    </option>
                `;
            });

            $("#clientFacture").html(html);
            $("#factureDetail").addClass("d-none");
        },
        error: function () {
            $("#clientFacture").html('<option value="">Erreur serveur</option>');
        }
    });
}

function chargerDetailFacture(reservationId) {
    $.ajax({
        url: "../api/admin_facture_detail.php",
        type: "GET",
        dataType: "json",
        data: {
            reservation_id: reservationId
        },
        success: function (response) {
            if (!response.success) {
                alert(response.message);
                return;
            }

            let html = "";

            response.lignes.forEach(function (ligne) {
                html += `
                    <tr>
                        <td>${ligne.designation}</td>
                        <td class="text-end">${formatPrix(ligne.montant)}</td>
                    </tr>
                `;
            });

            $("#factureBody").html(html);

            const reduction = parseFloat(response.reduction_prestations || 0);
            const montantReduction = parseFloat(response.montant_reduction || 0);
            const arrhes = parseFloat(response.arrhes || 0);

            $("#selectReduction").val(reduction);

            if (reduction > 0) {
                $("#ligneReduction").removeClass("d-none");
                $("#montantReduction").text("— " + formatPrix(montantReduction) + " (" + reduction + "%)");
            } else {
                $("#ligneReduction").addClass("d-none");
                $("#montantReduction").text("— 0 €");
            }

            if (arrhes > 0) {
                $("#ligneArrhes").removeClass("d-none");
                $("#montantArrhes").text("— " + formatPrix(arrhes));
                $("#arrheStatut").html('<span class="badge bg-success">Reçues</span>');
            } else {
                $("#ligneArrhes").addClass("d-none");
                $("#montantArrhes").text("— 0 €");
                $("#arrheStatut").html('<span class="badge bg-danger">Non reçues</span>');
            }

            $("#factureTotal").text(formatPrix(response.total));
            $("#factureDetail").removeClass("d-none");
        },
        error: function () {
            alert("Erreur lors du chargement de la facture.");
        }
    });
}

function appliquerReduction(reservationId, reduction) {
    $.ajax({
        url: "../api/admin_appliquerReduction.php",
        type: "POST",
        dataType: "json",
        data: {
            reservation_id: reservationId,
            reduction: reduction
        },
        success: function (response) {
            if (!response.success) {
                alert(response.message);
                return;
            }

            chargerDetailFacture(reservationId);
        },
        error: function () {
            alert("Erreur lors de l'application de la réduction.");
        }
    });
}

function formatPrix(montant) {
    return Number(montant).toFixed(2) + " €";
}

function confirmerArrhes(reservationId, montantArrhes) {
    $.ajax({
        url: "../api/admin_confirmerArrhes.php",
        type: "POST",
        dataType: "json",
        data: {
            reservation_id: reservationId,
            montant_arrhes: montantArrhes
        },
        success: function (response) {
            if (!response.success) {
                alert(response.message);
                return;
            }

            chargerDetailFacture(reservationId);
            $("#montantArrheInput").val("");
        },
        error: function () {
            alert("Erreur lors de l'enregistrement des arrhes.");
        }
    });
}

function chargerActivites() {
    const dateSelectionnee = $("#dateActivites").val();

    if (!dateSelectionnee) {
        $("#activitesBody").html(`
            <tr>
                <td colspan="7" class="text-center text-muted">
                    Choisissez une date.
                </td>
            </tr>
        `);
        return;
    }

    $.ajax({
        url: "../api/admin_activites.php",
        type: "GET",
        dataType: "json",
        data: {
            date: dateSelectionnee
        },
        success: function (response) {
            if (!response.success) {
                $("#activitesBody").html(`
                    <tr>
                        <td colspan="7" class="text-center text-danger">
                            ${response.message}
                        </td>
                    </tr>
                `);
                return;
            }

            const activites = response.activites || [];
            let html = "";

            if (activites.length === 0) {
                html = `
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Aucune demande d'activité pour cette date.
                        </td>
                    </tr>
                `;
            } else {
                activites.forEach(function (activite) {
                    let badgeClass = "bg-secondary";
                    let statutTexte = activite.statut || "Non défini";

                    if (activite.statut === "en_attente") {
                        badgeClass = "bg-warning text-dark";
                        statutTexte = "En attente";
                    } else if (activite.statut === "validee") {
                        badgeClass = "bg-success";
                        statutTexte = "Validée";
                    } else if (activite.statut === "refusee") {
                        badgeClass = "bg-danger";
                        statutTexte = "Refusée";
                    }

                    const participants = Array.isArray(activite.participants) && activite.participants.length > 0
                        ? activite.participants.join(", ")
                        : "Aucun";

                    const disabled = activite.statut === "en_attente" ? "" : "disabled";

                    html += `
                        <tr>
                            <td>
                                <input
                                    type="radio"
                                    name="activite_selectionnee"
                                    class="radio-activite"
                                    value="${activite.reservation_id}:${activite.activite_index}"
                                    data-reservation-id="${activite.reservation_id}"
                                    data-activite-index="${activite.activite_index}"
                                    ${disabled}
                                >
                            </td>
                            <td>${activite.client}</td>
                            <td>${activite.nom}</td>
                            <td>${activite.creneau || "-"}</td>
                            <td>${participants}</td>
                            <td>${activite.message || "-"}</td>
                            <td>
                                <span class="badge ${badgeClass}">${statutTexte}</span>
                                ${activite.animateur ? `<div class="small mt-1 text-muted">Animateur : ${activite.animateur}</div>` : ""}
                            </td>
                        </tr>
                    `;
                });
            }

            $("#activitesBody").html(html);

            // on vide la liste animateur tant qu'aucune activité n'est choisie
            resetSelectAnimateur();
        },
        error: function () {
            $("#activitesBody").html(`
                <tr>
                    <td colspan="7" class="text-center text-danger">
                        Erreur lors du chargement des activités.
                    </td>
                </tr>
            `);
        }
    });
}

function traiterActivitesSelectionnees(action) {
    const selection = $(".radio-activite:checked").val();
    const animateur = $("#selectAnimateur").val();

    if (!selection) {
        alert("Veuillez sélectionner une activité.");
        return;
    }

    if (action === "valider" && !animateur) {
        alert("Veuillez choisir un animateur.");
        return;
    }

    $.ajax({
        url: "../api/admin_traiterActivites.php",
        type: "POST",
        dataType: "json",
        data: {
            action: action,
            animateur: action === "valider" ? animateur : "",
            selection: selection
        },
        success: function (response) {
            if (!response.success) {
                alert(response.message);
                return;
            }

            resetSelectAnimateur();
            chargerActivites();
        },
        error: function () {
            alert("Erreur serveur lors du traitement des activités.");
        }
    });
}

function resetSelectAnimateur() {
    $("#selectAnimateur").val("");
}