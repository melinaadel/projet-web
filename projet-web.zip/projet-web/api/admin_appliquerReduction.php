<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Méthode non autorisée."
    ]);
    exit;
}

$reservationId = isset($_POST['reservation_id']) ? intval($_POST['reservation_id']) : 0;
$reduction = isset($_POST['reduction']) ? intval($_POST['reduction']) : 0;

if ($reservationId <= 0 || !in_array($reduction, [0, 10, 20, 50])) {
    echo json_encode([
        "success" => false,
        "message" => "Paramètres invalides."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

$trouvee = false;

foreach ($reservations as &$reservation) {
    if (isset($reservation['id']) && intval($reservation['id']) === $reservationId) {
        $reservation['reduction_prestations'] = $reduction;
        $trouvee = true;
        break;
    }
}

if (!$trouvee) {
    echo json_encode([
        "success" => false,
        "message" => "Réservation introuvable."
    ]);
    exit;
}

$ok = file_put_contents(
    $fichier,
    json_encode($reservations, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
);

if ($ok === false) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur lors de la sauvegarde."
    ]);
    exit;
}

echo json_encode([
    "success" => true,
    "message" => "Réduction appliquée avec succès."
]);