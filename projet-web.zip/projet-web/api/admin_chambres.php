<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

$date = isset($_GET['date']) ? trim($_GET['date']) : '';

if ($date === '') {
    echo json_encode([
        "success" => false,
        "message" => "Date manquante."
    ]);
    exit;
}

$fichierReservations = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichierReservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichierReservations), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

/*
Capacités fixes
*/
$capacites = [
    "Nuit Étoilée" => 15,
    "Sensorielle" => 15,
    "Silence Absolu" => 30,
    "Suite Lucide" => 20
];

/*
Initialisation
*/
$resultat = [];

foreach ($capacites as $nomChambre => $capacite) {
    $resultat[$nomChambre] = [
        "capacite" => $capacite,
        "reservees" => 0,
        "libres" => $capacite
    ];
}

/*
Compter les réservations acceptées qui couvrent la date sélectionnée
Règle :
- date_debut incluse
- date_fin exclue
Exemple : 2026-04-08 -> 2026-04-10
occupe les nuits du 08 et du 09, mais pas celle du 10
*/
foreach ($reservations as $reservation) {
    if (
        !isset($reservation['statut'], $reservation['chambre'], $reservation['date_debut'], $reservation['date_fin']) ||
        $reservation['statut'] !== 'acceptee'
    ) {
        continue;
    }

    $chambre = $reservation['chambre'];
    $dateDebut = $reservation['date_debut'];
    $dateFin = $reservation['date_fin'];

    if (!isset($resultat[$chambre])) {
        continue;
    }

    if ($date >= $dateDebut && $date < $dateFin) {
        $resultat[$chambre]['reservees']++;
    }
}

/*
Calculer libres
*/
foreach ($resultat as $nomChambre => $infos) {
    $resultat[$nomChambre]['libres'] = $infos['capacite'] - $infos['reservees'];
    if ($resultat[$nomChambre]['libres'] < 0) {
        $resultat[$nomChambre]['libres'] = 0;
    }
}

echo json_encode([
    "success" => true,
    "date" => $date,
    "chambres" => $resultat
]);