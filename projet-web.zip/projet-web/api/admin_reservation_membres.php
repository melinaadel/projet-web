<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

$reservationId = isset($_GET['reservation_id']) ? intval($_GET['reservation_id']) : 0;

if ($reservationId <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Réservation invalide."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

foreach ($reservations as $reservation) {
    if (isset($reservation['id']) && intval($reservation['id']) === $reservationId) {
        $membres = [];

        if (!empty($reservation['nom'])) {
            $membres[] = $reservation['nom'];
        }

        if (isset($reservation['noms_personnes']) && is_array($reservation['noms_personnes'])) {
            foreach ($reservation['noms_personnes'] as $personne) {
                if (!empty($personne)) {
                    $membres[] = $personne;
                }
            }
        }

        $membres = array_values(array_unique($membres));

        echo json_encode([
            "success" => true,
            "membres" => $membres
        ]);
        exit;
    }
}

echo json_encode([
    "success" => false,
    "message" => "Réservation introuvable."
]);