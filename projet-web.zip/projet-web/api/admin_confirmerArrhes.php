<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Méthode non autorisée."
    ]);
    exit;
}

$reservationId = isset($_POST['reservation_id']) ? intval($_POST['reservation_id']) : 0;
$montantArrhes = isset($_POST['montant_arrhes']) ? floatval($_POST['montant_arrhes']) : -1;

if ($reservationId <= 0 || $montantArrhes < 0) {
    echo json_encode([
        "success" => false,
        "message" => "Paramètres invalides."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

$trouvee = false;

foreach ($reservations as &$reservation) {
    if (isset($reservation['id']) && intval($reservation['id']) === $reservationId) {
        $reservation['arrhes'] = $montantArrhes;
        $trouvee = true;
        break;
    }
}

if (!$trouvee) {
    echo json_encode([
        "success" => false,
        "message" => "Réservation introuvable."
    ]);
    exit;
}

$ok = file_put_contents(
    $fichier,
    json_encode($reservations, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
);

if ($ok === false) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur lors de la sauvegarde des arrhes."
    ]);
    exit;
}

echo json_encode([
    "success" => true,
    "message" => "Arrhes enregistrées avec succès."
]);