<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Méthode non autorisée."
    ]);
    exit;
}

$action = isset($_POST['action']) ? trim($_POST['action']) : '';
$animateur = isset($_POST['animateur']) ? trim($_POST['animateur']) : '';
$selection = isset($_POST['selection']) ? trim($_POST['selection']) : '';

if (!in_array($action, ['valider', 'refuser'])) {
    echo json_encode([
        "success" => false,
        "message" => "Action invalide."
    ]);
    exit;
}

if ($selection === '') {
    echo json_encode([
        "success" => false,
        "message" => "Aucune activité sélectionnée."
    ]);
    exit;
}

if ($action === 'valider' && $animateur === '') {
    echo json_encode([
        "success" => false,
        "message" => "Veuillez choisir un animateur."
    ]);
    exit;
}

$parties = explode(':', $selection);

if (count($parties) !== 2) {
    echo json_encode([
        "success" => false,
        "message" => "Sélection invalide."
    ]);
    exit;
}

$reservationId = intval($parties[0]);
$activiteIndex = intval($parties[1]);

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

$trouvee = false;

foreach ($reservations as &$reservation) {
    if (!isset($reservation['id']) || intval($reservation['id']) !== $reservationId) {
        continue;
    }

    if (!isset($reservation['activites'][$activiteIndex])) {
        break;
    }

    if ($action === 'valider') {
        $reservation['activites'][$activiteIndex]['statut'] = 'validee';
        $reservation['activites'][$activiteIndex]['animateur'] = $animateur;
    } else {
        $reservation['activites'][$activiteIndex]['statut'] = 'refusee';
        $reservation['activites'][$activiteIndex]['animateur'] = '';
    }

    $trouvee = true;
    break;
}

if (!$trouvee) {
    echo json_encode([
        "success" => false,
        "message" => "Activité introuvable."
    ]);
    exit;
}

$ok = file_put_contents(
    $fichier,
    json_encode($reservations, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
);

if ($ok === false) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur lors de la sauvegarde."
    ]);
    exit;
}

echo json_encode([
    "success" => true,
    "message" => $action === 'valider'
        ? "Activité validée avec succès."
        : "Activité refusée avec succès."
]);