<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

$date = isset($_GET['date']) ? trim($_GET['date']) : '';

if ($date === '') {
    echo json_encode([
        "success" => false,
        "message" => "Date manquante."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

$activites = [];

foreach ($reservations as $reservation) {
    if (
        !isset($reservation['statut']) ||
        $reservation['statut'] !== 'acceptee' ||
        !isset($reservation['activites']) ||
        !is_array($reservation['activites'])
    ) {
        continue;
    }

    foreach ($reservation['activites'] as $index => $activite) {
        $dateActivite = isset($activite['date']) ? $activite['date'] : '';

        if ($dateActivite !== $date) {
            continue;
        }

        $participants = isset($activite['participants']) && is_array($activite['participants'])
            ? $activite['participants']
            : [];

        $activites[] = [
            "reservation_id" => $reservation['id'],
            "activite_index" => $index,
            "client" => $reservation['nom'],
            "email" => isset($reservation['email']) ? $reservation['email'] : '',
            "nom" => isset($activite['nom']) ? $activite['nom'] : 'Activité',
            "date" => $dateActivite,
            "creneau" => isset($activite['creneau']) ? $activite['creneau'] : '',
            "participants" => $participants,
            "message" => isset($activite['message']) ? $activite['message'] : '',
            "statut" => isset($activite['statut']) ? $activite['statut'] : '',
            "animateur" => isset($activite['animateur']) ? $activite['animateur'] : ''
        ];
    }
}

echo json_encode([
    "success" => true,
    "activites" => $activites
]);