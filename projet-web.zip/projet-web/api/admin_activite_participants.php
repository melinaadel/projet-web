<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

$reservationId = isset($_GET['reservation_id']) ? intval($_GET['reservation_id']) : 0;
$activiteIndex = isset($_GET['activite_index']) ? intval($_GET['activite_index']) : -1;

if ($reservationId <= 0 || $activiteIndex < 0) {
    echo json_encode([
        "success" => false,
        "message" => "Paramètres invalides."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

foreach ($reservations as $reservation) {
    if (!isset($reservation['id']) || intval($reservation['id']) !== $reservationId) {
        continue;
    }

    if (!isset($reservation['activites'][$activiteIndex])) {
        break;
    }

    $activite = $reservation['activites'][$activiteIndex];
    $participants = [];

    if (isset($activite['participants']) && is_array($activite['participants'])) {
        foreach ($activite['participants'] as $participant) {
            if (!empty($participant)) {
                $participants[] = $participant;
            }
        }
    }

    $participants = array_values(array_unique($participants));

    echo json_encode([
        "success" => true,
        "participants" => $participants
    ]);
    exit;
}

echo json_encode([
    "success" => false,
    "message" => "Activité introuvable."
]);