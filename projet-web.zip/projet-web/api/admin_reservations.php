<?php
session_start();
header('Content-Type: application/json');

// Sécurité : accès admin uniquement
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$contenu = file_get_contents($fichier);
$reservations = json_decode($contenu, true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

// Garder uniquement les réservations en attente
$reservationsEnAttente = array_values(array_filter($reservations, function ($reservation) {
    return isset($reservation['statut']) && $reservation['statut'] === 'en_attente';
}));

echo json_encode([
    "success" => true,
    "reservations" => $reservationsEnAttente
]);