<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

$reservationId = isset($_GET['reservation_id']) ? intval($_GET['reservation_id']) : 0;

if ($reservationId <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "Réservation invalide."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

$reservationTrouvee = null;

foreach ($reservations as $reservation) {
    if (
        isset($reservation['id']) &&
        intval($reservation['id']) === $reservationId &&
        isset($reservation['statut']) &&
        $reservation['statut'] === 'acceptee'
    ) {
        $reservationTrouvee = $reservation;
        break;
    }
}

if ($reservationTrouvee === null) {
    echo json_encode([
        "success" => false,
        "message" => "Réservation acceptée introuvable."
    ]);
    exit;
}

$dateDebut = new DateTime($reservationTrouvee['date_debut']);
$dateFin = new DateTime($reservationTrouvee['date_fin']);
$nbNuits = $dateDebut->diff($dateFin)->days;

if ($nbNuits < 1) {
    $nbNuits = 1;
}

$prixChambre = isset($reservationTrouvee['prix_chambre']) ? floatval($reservationTrouvee['prix_chambre']) : 0;
$totalChambre = $nbNuits * $prixChambre;

$lignes = [];
$lignes[] = [
    "designation" => "Chambre " . $reservationTrouvee['chambre'] . " (" . $nbNuits . " nuit(s))",
    "montant" => $totalChambre
];

$totalActivites = 0;
if (isset($reservationTrouvee['activites']) && is_array($reservationTrouvee['activites'])) {
    foreach ($reservationTrouvee['activites'] as $activite) {
        $prix = isset($activite['prix']) ? floatval($activite['prix']) : 0;
        $nom = isset($activite['nom']) ? $activite['nom'] : 'Activité';
        $totalActivites += $prix;

        $lignes[] = [
            "designation" => "Activité : " . $nom,
            "montant" => $prix
        ];
    }
}

$totalPrestations = 0;
if (isset($reservationTrouvee['prestations']) && is_array($reservationTrouvee['prestations'])) {
    foreach ($reservationTrouvee['prestations'] as $prestation) {
        $prix = isset($prestation['prix']) ? floatval($prestation['prix']) : 0;
        $nom = isset($prestation['nom']) ? $prestation['nom'] : 'Prestation';
        $totalPrestations += $prix;

        $lignes[] = [
            "designation" => "Prestation : " . $nom,
            "montant" => $prix
        ];
    }
}

$reductionPourcentage = isset($reservationTrouvee['reduction_prestations'])
    ? floatval($reservationTrouvee['reduction_prestations'])
    : 0;

$montantReduction = ($totalPrestations * $reductionPourcentage) / 100;
$montantArrhes = isset($reservationTrouvee['arrhes']) ? floatval($reservationTrouvee['arrhes']) : 0;

$totalBrut = $totalChambre + $totalActivites + $totalPrestations;
$totalFinal = $totalBrut - $montantReduction - $montantArrhes;

echo json_encode([
    "success" => true,
    "reservation" => [
        "id" => $reservationTrouvee['id'],
        "nom" => $reservationTrouvee['nom'],
        "email" => $reservationTrouvee['email'],
        "nb_nuits" => $nbNuits
    ],
    "lignes" => $lignes,
    "reduction_prestations" => $reductionPourcentage,
    "montant_reduction" => $montantReduction,
    "arrhes" => $montantArrhes,
    "total" => $totalFinal
]);