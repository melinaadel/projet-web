<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé."
    ]);
    exit;
}

$fichier = __DIR__ . '/../data/reservations.json';

if (!file_exists($fichier)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier reservations.json introuvable."
    ]);
    exit;
}

$reservations = json_decode(file_get_contents($fichier), true);

if (!is_array($reservations)) {
    echo json_encode([
        "success" => false,
        "message" => "Format JSON invalide."
    ]);
    exit;
}

$options = [];

foreach ($reservations as $reservation) {
    if (!isset($reservation['statut']) || $reservation['statut'] !== 'acceptee') {
        continue;
    }

    $options[] = [
        "id" => $reservation['id'],
        "nom" => $reservation['nom'],
        "email" => $reservation['email'],
        "date_debut" => $reservation['date_debut'],
        "date_fin" => $reservation['date_fin']
    ];
}

echo json_encode([
    "success" => true,
    "clients" => $options
]);