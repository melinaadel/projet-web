<?php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Méthode non autorisée."
    ]);
    exit;
}

$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';

if ($username === '' || $password === '') {
    echo json_encode([
        "success" => false,
        "message" => "Veuillez remplir tous les champs."
    ]);
    exit;
}

$adminFile = __DIR__ . '/../data/admin.json';

if (!file_exists($adminFile)) {
    echo json_encode([
        "success" => false,
        "message" => "Fichier admin introuvable."
    ]);
    exit;
}

$admins = json_decode(file_get_contents($adminFile), true);

if (!is_array($admins)) {
    echo json_encode([
        "success" => false,
        "message" => "Format admin.json invalide."
    ]);
    exit;
}

foreach ($admins as $admin) {
    if (
        isset($admin['username'], $admin['password']) &&
        $admin['username'] === $username &&
        $admin['password'] === $password
    ) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;

        echo json_encode([
            "success" => true,
            "message" => "Connexion réussie.",
            "username" => $username
        ]);
        exit;
    }
}

echo json_encode([
    "success" => false,
    "message" => "Identifiants incorrects."
]);